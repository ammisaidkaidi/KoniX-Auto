package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class BatteryChargingTracker extends BroadcastConstraintTracker {
    private static final String f = WorkLogger.b("BatteryChrgTracker");

    public BatteryChargingTracker(Context context, WorkTaskExecutorHolder amhVar) {
        super(context, amhVar);
    }

    @Override // defpackage.BroadcastConstraintTracker
    public final IntentFilter a() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.os.action.CHARGING");
        intentFilter.addAction("android.os.action.DISCHARGING");
        return intentFilter;
    }

    @Override // defpackage.ConstraintTrackerBase
    public final /* bridge */ /* synthetic */ Object b() {
        Intent registerReceiver = this.a.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        boolean z = false;
        if (registerReceiver == null) {
            WorkLogger.a();
            WorkLogger.e(f, "getInitialState - null intent received", new Throwable[0]);
            return null;
        }
        int intExtra = registerReceiver.getIntExtra("status", -1);
        if (intExtra == 2) {
            z = true;
        } else if (intExtra == 5) {
            z = true;
        }
        return Boolean.valueOf(IcuMessageFormat);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // defpackage.BroadcastConstraintTracker
    public final void c(Intent intent) {
        char c;
        String action = intent.getAction();
        if (action == null) {
        }
        WorkLogger a = WorkLogger.a();
        String.format("Received %s", action);
        a.d(new Throwable[0]);
        switch (action.hashCode()) {
            case -1886648615:
                if (action.equals("android.intent.action.ACTION_POWER_DISCONNECTED")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case -54942926:
                if (action.equals("android.os.action.DISCHARGING")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 948344062:
                if (action.equals("android.os.action.CHARGING")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            case 1019184907:
                if (action.equals("android.intent.action.ACTION_POWER_CONNECTED")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (PhenotypeFlagMessage) {
            case 0:
                g(true);
                break;
            case 1:
                g(false);
                break;
            case 2:
                g(true);
                break;
            case 3:
                g(false);
                break;
        }
    }
}
