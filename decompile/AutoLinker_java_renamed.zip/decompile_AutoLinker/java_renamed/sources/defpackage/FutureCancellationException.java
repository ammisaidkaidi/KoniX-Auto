package defpackage;

/* compiled from: PG */
/* loaded from: classes.dex */
final class FutureCancellationException extends Throwable {
    public FutureCancellationException() {
        super("Failure occurred while trying to finish a future.");
    }

    @Override // java.lang.Throwable
    public final synchronized Throwable fillInStackTrace() {
        return this;
    }
}
