package defpackage;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class vt {
    public static final String[] a = {"standard", "accelerate", "decelerate", "linear"};

    public final String toString() {
        throw null;
    }
}
