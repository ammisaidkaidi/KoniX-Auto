package defpackage;

import android.content.Context;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/* compiled from: PG */
/* loaded from: classes.dex */
public final class tp {
    public final Set a = new CopyOnWriteArraySet();
    public volatile Context b;
}
