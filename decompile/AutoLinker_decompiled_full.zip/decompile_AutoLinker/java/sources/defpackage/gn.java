package defpackage;

import android.content.ClipData;
import android.view.ContentInfo;

/* compiled from: PG */
/* loaded from: classes.dex */
public interface gn {
    int a();

    int b();

    ClipData c();

    ContentInfo d();
}
